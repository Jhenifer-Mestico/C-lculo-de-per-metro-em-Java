/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perimetro;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class Perimetro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         float ladoa,ladob,perim,area;
    Scanner inputData = new Scanner(System.in);
    System.out.println("Digite um número de um lado (em cm):");
    ladoa = inputData.nextFloat(); 
    
    System.out.println("Digite um número do outro lado (em cm):");
    ladob = inputData.nextFloat(); 
    
    perim = 2*ladoa + 2*ladob;
    
    System.out.println("Perímetro:" + perim + "cm");
    
    area = ladoa*ladob;
    System.out.println("Área do retângulo:" + area + "cm ao quadrado");
    }
    
}
